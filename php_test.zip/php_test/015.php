<?php
$title = "〇に火がつく";
$subtitle = "切迫して落ち着いていられない";
$question = array();
$question = array("顎(アゴ)","足(アシ)","靨(エクボ)","腰(コシ)","舌(シタ)","髪(カミ)","腕(ウデ)","目(メ)","耳(ミミ)","尻(シリ)","背(セ)","腹(ハラ)","手(テ)","顔(カオ)","肩(カタ)","爪(ツメ)","鼻(ハナ)","胆(キモ)","口(クチ)","面(ツラ)","額(ヒタイ)","歯(ハ)","肌(ハダ)","臍(ヘソ)","眉(マユ)","胸(ムネ)"); //選択肢を設定(最初の選択肢が正解)
$answer = $question[9];
shuffle($question);
?>

<!doctype html>
<html>

<head>
<meta charset="utf-8">
<meta name="robots" content="noindex, nofollow">
<title>問題</title>
</head>

<body>
<h1><?php echo $title ?></h1>
<h2><?php echo $subtitle ?></h2>
<form method="POST" action="a.php">
<p>
<?php foreach($question as $value){ ?>
<input type="radio" name="question" value="<?php echo $value; ?>"> <?php echo $value; ?><br>
<?php } ?>
<input type="radio" name="question" value="none" checked="checked" style="display:none;">
<input type="hidden" name="answer" value="<?php echo $answer ?>">
<input type="submit" value="回答する">
</p>
</form>
</body>

</html>