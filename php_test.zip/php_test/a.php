<!doctype html>
<html>

<head>
<meta charset="utf-8">
<meta name="robots" content="noindex, nofollow">
<title>結果</title>
</head>

<body>
<h1>結果</h1>
<?php
$counter_file = 'counter.txt';
$counter_lenght = 8;

$fp = fopen($counter_file, 'r+');

if ($fp){
    if (flock($fp, LOCK_EX)){

        $counter = fgets($fp, $counter_lenght);
        $counter++;

        rewind($fp);

        if (fwrite($fp,  $counter) === FALSE){
            print('ファイル書き込みに失敗しました');
        }

        flock($fp, LOCK_UN);
    }
}

fclose($fp);

print('count:'.$counter);

$q_txt_file = 'q.txt';
$qfp = fopen($q_txt_file, 'a');
$question = $_POST['question'];
$answer = $_POST['answer'];
if($question == $answer){
$result = "正解";
fwrite($qfp, "〇\n");
}elseif($question == 'none'){
$result = "無回答";
fwrite($qfp, "無\n");
}else{
$result = "不正解";
fwrite($qfp, "☓\n");
}
fclose($qfp)
?>
<p><?php echo $result ?></p>
<p>
<?php
$rand_file = 'q.dat';
$random = file_exists($rand_file);
$link = $random ?file($rand_file) : array();
$rand_c = count($link);
$rand_c = $rand_c - 1;
$r = rand(0, $rand_c);
$bun = $link[$r];
echo "<a href=\"{$bun}\">次の問題へ</a>";
?>
</p>
<p><a href="/">トップへもどる</a></p>

</body>

</html>