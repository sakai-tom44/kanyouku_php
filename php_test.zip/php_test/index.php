<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>問題集</title>
</head>

<body>
<div>
<h1>問題集</h1>
<p>
<?php
$rand_file = 'q.dat';
$random = file_exists($rand_file);
$link = $random ?file($rand_file) : array();
$rand_c = count($link);
$rand_c = $rand_c - 1;
$r = rand(0, $rand_c);
$bun = $link[$r];
echo "<a href=\"{$bun}\">はじめる</a>";
?>
</p>
</div>
</body>
</html>